package mygame_server;
 public class Server
{
	String name;
	void display(String name)
	{
		this.name=name;
System.out.println(name);
	
}
public static void main(String[] args) {
	
}
}