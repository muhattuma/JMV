package mygame_shared;
 public class Utility
{
	String name;
	void display1(String name)
	{
		this.name=name;
System.out.println(name);
	
}
public static void main(String[] args) {
	
}
}