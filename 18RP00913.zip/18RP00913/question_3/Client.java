package mygame_client;
import myserver.*;
import mygame_shared.*;
public class Client
{
	String name;
	void display12(String name )
	{
		this.name=name;
System.out.println(name);
	
}

public static void main(String[] args) {
	Server g=new Server();
	g. display("I am Server");
	Utility d=new Utility();
	d.display1("I am Utility");
	 Client a=new  Client();
	 a.display12("I am Client");
}
}