class Engine
{
	String display()
	{
		System.out.println("I am an Enngine ");
	return null;
	}
}