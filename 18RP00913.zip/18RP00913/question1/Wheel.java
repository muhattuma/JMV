class Wheel
{
	int count;
	int position;
	Wheel()
	{

	}
	String display2()
	{
		for( count=1;count<=position;count++)
		{
			System.out.println("I am a Wheel No :"+count);
		}
					return null;

	}
}