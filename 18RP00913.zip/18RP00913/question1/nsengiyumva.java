/**
* On my honor , as Rwanda Polytechnic/IPRC Tumba Student,
*Ihave neither given nor recieved unouthorized assistence on 
*This work.
*@ author {Nsengiyumva Jean Marie Viannet}
*Date January 25,2020 */
class Fluffydice
{
	String color;
	Fluffydice(String color)
	{

	}
	 String  diplay()
	 {
	 	System.out.println("I am fluffy Red"+color);
	 return null;	
	 }

}
