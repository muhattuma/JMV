
class Car
{
	int count;
	String name;
	Engine engine;
	Wheel wheel;
	Fullydice fullydice;
	Car()
{

}
Car(String name)
{
this.name=name;
}
 void setFullyDice(Fullydice fullydice)
{

}
 String display3()
 {
 	System.out.println("Car name :"+ca.name);
 	return null;
 }
 void controller()
 {
 public static void main(String[] args) {
 	 Car ca =new Car();
 	 ca.display3("BMW");
 	Engine n=new Engine();
 	n.display();
 	 Wheel d=new d();
 	 d.display2(4);
 	FluffyDice m=new FluffyDice();
 	m.diplay1("Red");
 	
 	
 }

 }
}