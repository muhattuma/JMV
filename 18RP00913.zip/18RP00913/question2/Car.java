class Car
{
	String plateNumber;
	String manufactuer;
	Item fs;
 Car(String plateNumber, String manufactuer,Item fs)
 {
 	this.plateNumber=plateNumber;
 	this.manufactuer=manufactuer;
 }
String display()
{
	System.out.println("Car ");
	System.out.println("name :"+id.name);
	System.out.println("name :"+id.category);
	System.out.println("name :"+id.price);
	System.out.println("name :"+plateNumber);
	System.out.println("name :"+manufactuer);

}
public static void main(String[] args) {
	Item id=new Item("BMW","Utility");
	 Car ns=new Car("RAB123B","Thus_jan_01");
}
}