class Property
{
	int bedroom;
	int area;
	int age;
	Item it;
	
	Property(int bedroom,int area,int age,Item it;)
{
	this.bedroom=bedroom;
	this.area=area;
	this.age=age;

}
String display()
{
	System.out.println("property :");
	System.out.println("property :"+n.name);
	System.out.println("property :"+n.category);
	System.out.println("property :"+n.rpice);
	System.out.println("property :"+bedroom);
	System.out.println("property :"+area);
	System.out.println("property :"+age);

	return null;

}
public static void main(String[] args) {
	Item n=new Item("VIP","property",100000.22);
	Property m=new Property(4,200,5);



	
}

}