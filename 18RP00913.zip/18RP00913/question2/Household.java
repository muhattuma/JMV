class Household
{
	String condition;
	String picture;
	Item ita;
	Household(String condition,String picture,Item ita)
	{
		this.condition=condition;
		this.picture=picture;
	}
	String display()
	{
		System.out.println("Household");
		System.out.println("name :"+ms.name);
		System.out.println("name :"+ms.category);
		System.out.println("name :"+ms.price);
		System.out.println("name :"+condition);
		System.out.println("name :"+picture);
		return null;
	}
	public static void main(String[] args) {
		Item ms=new Item("Flask","Utility",5000.0);
		Household nes=new Household("Used","http://www.picture.com/Flask");


	}
}