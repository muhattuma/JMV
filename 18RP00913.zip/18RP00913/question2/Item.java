//nsengiyumva jean marie vianney 18rp00913
class Item
{
	String name;
	String category;
	double price;
	Item(String name,String category,double price)
	{
		this.name=name;
		this.category=category;
		this.price=price;
	}
}
 

